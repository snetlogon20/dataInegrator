import pandas as pd
import json
import jsonschema

# 示例数据：用户列表DataFrame
data = [{'col1': 'a', 'col2': 4.0},
        {'col1': 'a', 'col2': 4.0},
        {'col1': 'a', 'col2': 5.0}]
user_df = pd.DataFrame(data)
print(user_df)

# 示例模式（schema），指定在JSON中的位置
schema = {
    "root": {
        "users": user_df.to_dict(orient='records')
    }
}

# 定义 JSON Schema
json_schema = {
    "type": "object",
    "properties": {
        "root": {
            "type": "object",
            "properties": {
                "users": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "col1": {
                                "type": "string"
                            },
                            "col2": {
                                "type": "number"
                            }
                        },
                        "required": ["col1", "col2"]
                    }
                }
            },
            "required": ["users"]
        }
    },
    "required": ["root"]
}

if __name__ == "__main__":
    # 将模式转换为JSON字符串
    json_output = json.dumps(schema, indent=4)

    # 打印JSON字符串
    print(json_output)

    # 如果你想将JSON保存到文件中
    with open('WriteExcelBySchema.json', 'w') as f:
        f.write(json_output)

    try:
        # 验证 JSON 数据
        jsonschema.validate(instance=schema, schema=json_schema)
        print("JSON 数据验证通过")
    except jsonschema.exceptions.ValidationError as e:
        print(f"JSON 数据验证失败: {e}")